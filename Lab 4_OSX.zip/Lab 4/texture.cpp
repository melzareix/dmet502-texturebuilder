#include "TextureBuilder.h"
#include <GLUT/glut.h>
#include <iostream>

#define GLUT_KEY_ESCAPE 27

GLuint texID;

int rep = 1;

void Display(void) {
  glClear(GL_COLOR_BUFFER_BIT);

  glPushMatrix();

  glBindTexture(GL_TEXTURE_2D, texID);

  glBegin(GL_QUADS);
  glTexCoord2f(0.0f, 0.0f);
  glVertex3f(200, 200, 0);
  glTexCoord2f(rep, 0.0f);
  glVertex3f(500, 200, 0);
  glTexCoord2f(rep, rep);
  glVertex3f(500, 500, 0);
  glTexCoord2f(0.0f, rep);
  glVertex3f(200, 500, 0);
  glEnd();

  glPopMatrix();

  glFlush();
}

void Keyboard(unsigned char key, int x, int y) {
  if (key==GLUT_KEY_ESCAPE)
    exit(EXIT_SUCCESS);
}

int main(int argc, char **argv) {
  glutInit(&argc, argv);

  glutInitWindowSize(600, 600);
  glutInitWindowPosition(50, 50);

  glutCreateWindow("Texture 2D");
  glutDisplayFunc(Display);

  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
  glClearColor(1.0f, 1.0f, 1.0f, 0.0f);

  glEnable(GL_TEXTURE_2D);

  gluOrtho2D(0, 600, 0, 600);

  loadBMP(&texID, "textures/metal.bmp", true);
//	loadPPM(&texID, "textures/clouds.ppm", 200, 200, true);

  glutMainLoop();
}